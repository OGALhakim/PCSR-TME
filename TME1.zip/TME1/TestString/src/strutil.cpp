// strutil.cpp
#include "strutil.h"

namespace pr {

size_t length(const char* s) {

    return 0;
}

char* newcopy(const char* s) {

    return nullptr;
}

int compare(const char* a, const char* b) {

    return 0;
}

}
